let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let imgMachado; // Renomeado para maior clareza
let machado; // Instância do machado

let tempoParaProximoCorte = 0; // Tempo até o machado aparecer novamente

function preload() {
  imgMachado = loadImage("machado.png"); // Carrega a imagem do machado
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
  machado = new Machado(); // Cria a instância do machado

  // Define um tempo inicial para o machado aparecer
  tempoParaProximoCorte = millis() + random(5000, 15000); // Entre 5 e 15 segundos
}

function draw() {
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
  mostrarInformacao();

  jardineiro.mostrar();
  jardineiro.atualizar();

  // Atualiza e exibe as árvores
  for (let i = plantas.length - 1; i >= 0; i--) {
    plantas[i].mostrar();
  }

  // Lógica do machado
  machado.atualizar();
  machado.exibir();

  // Controle da temperatura
  temperatura += 0.01; // Ajuste a taxa de aumento da temperatura
  if (temperatura > 30) temperatura = 30; // Limite máximo para a temperatura
}

function mostrarInformacao() {
  textSize(20);
  fill(0); // Cor do texto preta
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text("Árvores plantadas: " + totalArvores, 10, 50);
  text("Para movimentar o personagem use as setas do teclado.", 10, 70);
  text("Pressione 'Espaço' ou 'P' para plantar uma árvore.", 10, 90);
}

// Classe que cria o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👨‍🌾';
    this.velocidade = 3;
    this.tamanho = 32; // Tamanho do emoji para colisão
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limitar o jardineiro dentro da tela
    this.x = constrain(this.x, 0 + this.tamanho / 2, width - this.tamanho / 2);
    this.y = constrain(this.y, 0 + this.tamanho / 2, height - this.tamanho / 2);
  }

  mostrar() {
    textSize(this.tamanho);
    text(this.emoji, this.x, this.y);
  }

  // Verifica se o jardineiro está em uma posição de plantio válida
  podePlantar(arvoreX, arvoreY) {
    // Verifica se já existe uma árvore muito próxima
    for (let arvore of plantas) {
      let d = dist(arvoreX, arvoreY, arvore.x, arvore.y);
      if (d < 30) { // Distância mínima entre árvores
        return false;
      }
    }
    // Verifica se a posição não está muito próxima do machado quando ativo
    if (machado.ativo && dist(arvoreX, arvoreY, machado.x, machado.y) < 50) {
      return false;
    }
    return true;
  }
}

function keyPressed() {
  if (key === ' ' || key === 'p') {
    // Ajusta a posição de plantio para não ser sobre o jardineiro
    let plantX = jardineiro.x;
    let plantY = jardineiro.y;

    if (jardineiro.podePlantar(plantX, plantY)) {
      let arvore = new Arvore(plantX, plantY);
      plantas.push(arvore);
      totalArvores++;
      temperatura -= 3;
      if (temperatura < 0) temperatura = 0;
    } else {
      // Opcional: mostrar uma mensagem para o jogador que não pode plantar aqui
      console.log("Não é possível plantar aqui!");
    }
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
    this.tamanho = 32; // Tamanho do emoji para colisão
  }

  mostrar() {
    textSize(this.tamanho);
    text(this.emoji, this.x, this.y);
  }
}

class Machado {
  constructor() {
    this.x = -100; // Começa fora da tela
    this.y = -100;
    this.tamanho = 150; // Tamanho do machado para detecção de colisão
    this.ativo = false; // Indica se o machado está visível e ativo
    this.velocidade = 5; // Velocidade de movimento do machado
    this.alvoX = 0;
    this.alvoY = 0;
  }

  exibir() {
    if (this.ativo) {
      image(imgMachado, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
    }
  }

  atualizar() {
    // Verifica se é hora de o machado aparecer
    if (!this.ativo && millis() > tempoParaProximoCorte) {
      this.ativar();
    }

    if (this.ativo) {
      // Move o machado em direção ao alvo
      this.x = lerp(this.x, this.alvoX, 0.05); // Suaviza o movimento
      this.y = lerp(this.y, this.alvoY, 0.05);

      // Se o machado chegou perto do alvo, corta uma árvore
      if (dist(this.x, this.y, this.alvoX, this.alvoY) < 5) {
        this.cortarArvore();
      }
    }
  }

  ativar() {
    this.ativo = true;
    // Escolhe uma árvore aleatória para ser o alvo
    if (plantas.length > 0) {
      let arvoreAlvo = random(plantas);
      this.alvoX = arvoreAlvo.x;
      this.alvoY = arvoreAlvo.y;
      // Posiciona o machado aleatoriamente na borda da tela
      let borda = floor(random(4)); // 0: cima, 1: direita, 2: baixo, 3: esquerda
      switch (borda) {
        case 0: // Cima
          this.x = random(width);
          this.y = -this.tamanho;
          break;
        case 1: // Direita
          this.x = width + this.tamanho;
          this.y = random(height);
          break;
        case 2: // Baixo
          this.x = random(width);
          this.y = height + this.tamanho;
          break;
        case 3: // Esquerda
          this.x = -this.tamanho;
          this.y = random(height);
          break;
      }
    } else {
      // Se não há árvores, o machado aparece em um local aleatório e logo some
      this.x = random(width);
      this.y = random(height);
      setTimeout(() => this.desativar(), 1000); // Some depois de 1 segundo
    }
  }

  cortarArvore() {
    let arvoreCortada = false;
    for (let i = plantas.length - 1; i >= 0; i--) {
      let arvore = plantas[i];
      let d = dist(this.x, this.y, arvore.x, arvore.y);
      if (d < this.tamanho / 2 + arvore.tamanho / 2) { // Colisão com a árvore
        plantas.splice(i, 1); // Remove a árvore
        totalArvores--;
        temperatura += 5; // Aumenta a temperatura ao cortar uma árvore
        arvoreCortada = true;
        break; // Corta apenas uma árvore por vez
      }
    }

    if (arvoreCortada || plantas.length === 0) {
      this.desativar();
    } else {
      // Se não cortou, escolhe um novo alvo (pode ter mudado de posição)
      this.ativar();
    }
  }

  desativar() {
    this.ativo = false;
    this.x = -100; // Move para fora da tela
    this.y = -100;
    // Define o tempo para a próxima aparição
    tempoParaProximoCorte = millis() + random(5000, 15000); // Entre 5 e 15 segundos
  }
}
  
  
  
  
  
